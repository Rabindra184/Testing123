// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

package corp.stryker.openqa.selenium.remote.http;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.io.Resources;

import corp.stryker.openqa.selenium.WebDriverException;
import corp.stryker.openqa.selenium.remote.DriverCommand;
import corp.stryker.openqa.selenium.remote.RemoteWebElement;
import corp.stryker.openqa.selenium.interactions.Interaction;
import corp.stryker.openqa.selenium.interactions.KeyInput;
import corp.stryker.openqa.selenium.interactions.PointerInput;
import corp.stryker.openqa.selenium.interactions.Sequence;
import corp.stryker.openqa.selenium.remote.internal.WebElementToJsonConverter;

import java.io.IOException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;


/**
 * A command codec that adheres to the W3C's WebDriver wire protocol.
 *
 * @see <a href="https://w3.org/tr/webdriver">W3C WebDriver spec</a>
 */
public class W3CHttpCommandCodec extends AbstractHttpCommandCodec {

  private final PointerInput mouse = new PointerInput(PointerInput.Kind.MOUSE, "mouse");
  private final KeyInput keyboard = new KeyInput("keyboard");

  public W3CHttpCommandCodec() {
    alias(DriverCommand.GET_ELEMENT_ATTRIBUTE, DriverCommand.EXECUTE_SCRIPT);
    alias(DriverCommand.GET_ELEMENT_LOCATION, DriverCommand.GET_ELEMENT_RECT);
    alias(DriverCommand.GET_ELEMENT_LOCATION_ONCE_SCROLLED_INTO_VIEW, DriverCommand.EXECUTE_SCRIPT);
    alias(DriverCommand.GET_ELEMENT_SIZE, DriverCommand.GET_ELEMENT_RECT);
    alias(DriverCommand.IS_ELEMENT_DISPLAYED, DriverCommand.EXECUTE_SCRIPT);
    alias(DriverCommand.SUBMIT_ELEMENT, DriverCommand.EXECUTE_SCRIPT);

    defineCommand(DriverCommand.EXECUTE_SCRIPT, post("/session/:sessionId/execute/sync"));
    defineCommand(DriverCommand.EXECUTE_ASYNC_SCRIPT, post("/session/:sessionId/execute/async"));

    alias(DriverCommand.GET_PAGE_SOURCE, DriverCommand.EXECUTE_SCRIPT);
    alias(DriverCommand.CLEAR_LOCAL_STORAGE, DriverCommand.EXECUTE_SCRIPT);
    alias(DriverCommand.GET_LOCAL_STORAGE_KEYS, DriverCommand.EXECUTE_SCRIPT);
    alias(DriverCommand.SET_LOCAL_STORAGE_ITEM, DriverCommand.EXECUTE_SCRIPT);
    alias(DriverCommand.REMOVE_LOCAL_STORAGE_ITEM, DriverCommand.EXECUTE_SCRIPT);
    alias(DriverCommand.GET_LOCAL_STORAGE_ITEM, DriverCommand.EXECUTE_SCRIPT);
    alias(DriverCommand.GET_LOCAL_STORAGE_SIZE, DriverCommand.EXECUTE_SCRIPT);
    alias(DriverCommand.CLEAR_SESSION_STORAGE, DriverCommand.EXECUTE_SCRIPT);
    alias(DriverCommand.GET_SESSION_STORAGE_KEYS, DriverCommand.EXECUTE_SCRIPT);
    alias(DriverCommand.SET_SESSION_STORAGE_ITEM, DriverCommand.EXECUTE_SCRIPT);
    alias(DriverCommand.REMOVE_SESSION_STORAGE_ITEM, DriverCommand.EXECUTE_SCRIPT);
    alias(DriverCommand.GET_SESSION_STORAGE_ITEM, DriverCommand.EXECUTE_SCRIPT);
    alias(DriverCommand.GET_SESSION_STORAGE_SIZE, DriverCommand.EXECUTE_SCRIPT);

    defineCommand(DriverCommand.MAXIMIZE_CURRENT_WINDOW, post("/session/:sessionId/window/maximize"));
    defineCommand(DriverCommand.GET_CURRENT_WINDOW_SIZE, get("/session/:sessionId/window/rect"));
    defineCommand(DriverCommand.SET_CURRENT_WINDOW_SIZE, post("/session/:sessionId/window/rect"));
    alias(DriverCommand.GET_CURRENT_WINDOW_POSITION, DriverCommand.GET_CURRENT_WINDOW_SIZE);
    alias(DriverCommand.SET_CURRENT_WINDOW_POSITION, DriverCommand.SET_CURRENT_WINDOW_SIZE);
    defineCommand(DriverCommand.GET_CURRENT_WINDOW_HANDLE, get("/session/:sessionId/window"));
    defineCommand(DriverCommand.GET_WINDOW_HANDLES, get("/session/:sessionId/window/handles"));

    defineCommand(DriverCommand.ACCEPT_ALERT, post("/session/:sessionId/alert/accept"));
    defineCommand(DriverCommand.DISMISS_ALERT, post("/session/:sessionId/alert/dismiss"));
    defineCommand(DriverCommand.GET_ALERT_TEXT, get("/session/:sessionId/alert/text"));
    defineCommand(DriverCommand.SET_ALERT_VALUE, post("/session/:sessionId/alert/text"));

    defineCommand(DriverCommand.GET_ACTIVE_ELEMENT, get("/session/:sessionId/element/active"));

    defineCommand(DriverCommand.ACTIONS, post("/session/:sessionId/actions"));
    defineCommand(DriverCommand.CLEAR_ACTIONS_STATE, delete("/session/:sessionId/actions"));

    // Emulate the old Actions API since everyone still likes to call these things.
    alias(DriverCommand.CLICK, DriverCommand.ACTIONS);
    alias(DriverCommand.DOUBLE_CLICK, DriverCommand.ACTIONS);
    alias(DriverCommand.MOUSE_DOWN, DriverCommand.ACTIONS);
    alias(DriverCommand.MOUSE_UP, DriverCommand.ACTIONS);
    alias(DriverCommand.MOVE_TO, DriverCommand.ACTIONS);
  }

  @Override
  protected Map<String, ?> amendParameters(String name, Map<String, ?> parameters) {
    switch (name) {
      case DriverCommand.CLICK:
        return ImmutableMap.<String, Object>builder()
            .put("actions", ImmutableList.of(
                new Sequence(mouse, 0)
                    .addAction(mouse.createPointerDown(PointerInput.MouseButton.LEFT.asArg()))
                    .addAction(mouse.createPointerUp(PointerInput.MouseButton.LEFT.asArg()))
                    .toJson()))
            .build();

      case DriverCommand.DOUBLE_CLICK:
        return ImmutableMap.<String, Object>builder()
            .put("actions", ImmutableList.of(
                new Sequence(mouse, 0)
                    .addAction(mouse.createPointerDown(PointerInput.MouseButton.LEFT.asArg()))
                    .addAction(mouse.createPointerUp(PointerInput.MouseButton.LEFT.asArg()))
                    .addAction(mouse.createPointerDown(PointerInput.MouseButton.LEFT.asArg()))
                    .addAction(mouse.createPointerUp(PointerInput.MouseButton.LEFT.asArg()))
                    .toJson()))
            .build();

      case DriverCommand.FIND_CHILD_ELEMENT:
      case DriverCommand.FIND_CHILD_ELEMENTS:
      case DriverCommand.FIND_ELEMENT:
      case DriverCommand.FIND_ELEMENTS:
        String using = (String) parameters.get("using");
        String value = (String) parameters.get("value");

        Map<String, Object> toReturn = new HashMap<>(parameters);

        switch (using) {
          case "class name":
            toReturn.put("using", "css selector");
            toReturn.put("value", "." + cssEscape(value));
            break;

          case "id":
            toReturn.put("using", "css selector");
            toReturn.put("value", "#" + cssEscape(value));
            break;

          case "link text":
            // Do nothing
            break;

          case "name":
            toReturn.put("using", "css selector");
            toReturn.put("value", "*[name='" + value + "']");
            break;

          case "partial link text":
            // Do nothing
            break;

          case "tag name":
            toReturn.put("using", "css selector");
            toReturn.put("value", cssEscape(value));
            break;

          case "xpath":
            // Do nothing
            break;
        }
        return toReturn;

      case DriverCommand.GET_ELEMENT_ATTRIBUTE:
        // Read the atom, wrap it, execute it.
        return executeAtom(
          "getAttribute.js",
          asElement(parameters.get("id")),
          parameters.get("name"));

      case DriverCommand.GET_ELEMENT_LOCATION_ONCE_SCROLLED_INTO_VIEW:
        return toScript(
          "var e = arguments[0]; e.scrollIntoView({behavior: 'instant', block: 'end', inline: 'nearest'}); var rect = e.getBoundingClientRect(); return {'x': rect.left, 'y': rect.top};",
          asElement(parameters.get("id")));

      case DriverCommand.GET_PAGE_SOURCE:
        return toScript(
          "var source = document.documentElement.outerHTML; \n" +
          "if (!source) { source = new XMLSerializer().serializeToString(document); }\n" +
          "return source;");

      case DriverCommand.CLEAR_LOCAL_STORAGE:
        return toScript("localStorage.clear()");

      case DriverCommand.GET_LOCAL_STORAGE_KEYS:
        return toScript("return Object.keys(localStorage)");

      case DriverCommand.SET_LOCAL_STORAGE_ITEM:
        return toScript("localStorage.setItem(arguments[0], arguments[1])",
                        parameters.get("key"), parameters.get("value"));

      case DriverCommand.REMOVE_LOCAL_STORAGE_ITEM:
        return toScript("var item = localStorage.getItem(arguments[0]); localStorage.removeItem(arguments[0]); return item",
                        parameters.get("key"));

      case DriverCommand.GET_LOCAL_STORAGE_ITEM:
        return toScript("return localStorage.getItem(arguments[0])", parameters.get("key"));

      case DriverCommand.GET_LOCAL_STORAGE_SIZE:
        return toScript("return localStorage.length");

      case DriverCommand.CLEAR_SESSION_STORAGE:
        return toScript("sessionStorage.clear()");

      case DriverCommand.GET_SESSION_STORAGE_KEYS:
        return toScript("return Object.keys(sessionStorage)");

      case DriverCommand.SET_SESSION_STORAGE_ITEM:
        return toScript("sessionStorage.setItem(arguments[0], arguments[1])",
                        parameters.get("key"), parameters.get("value"));

      case DriverCommand.REMOVE_SESSION_STORAGE_ITEM:
        return toScript("var item = sessionStorage.getItem(arguments[0]); sessionStorage.removeItem(arguments[0]); return item",
                        parameters.get("key"));

      case DriverCommand.GET_SESSION_STORAGE_ITEM:
        return toScript("return sessionStorage.getItem(arguments[0])", parameters.get("key"));

      case DriverCommand.GET_SESSION_STORAGE_SIZE:
        return toScript("return sessionStorage.length");

      case DriverCommand.IS_ELEMENT_DISPLAYED:
        return executeAtom("isDisplayed.js", asElement(parameters.get("id")));

      case DriverCommand.MOUSE_DOWN:
        Interaction mouseDown = mouse.createPointerDown(PointerInput.MouseButton.LEFT.asArg());
        return ImmutableMap.<String, Object>builder()
            .put("actions", ImmutableList.of(new Sequence(mouse, 0).addAction(mouseDown).toJson()))
            .build();

      case DriverCommand.MOUSE_UP:
        Interaction mouseUp = mouse.createPointerUp(PointerInput.MouseButton.LEFT.asArg());
        return ImmutableMap.<String, Object>builder()
            .put("actions", ImmutableList.of(new Sequence(mouse, 0).addAction(mouseUp).toJson()))
            .build();

      case DriverCommand.MOVE_TO:
        PointerInput.Origin origin = PointerInput.Origin.pointer();
        if (parameters.containsKey("element")) {
          RemoteWebElement element = new RemoteWebElement();
          element.setId((String) parameters.get("element"));
          origin = PointerInput.Origin.fromElement(element);
        }
        int x = parameters.containsKey("xoffset") ? ((Number) parameters.get("xoffset")).intValue() : 0;
        int y = parameters.containsKey("yoffset") ? ((Number) parameters.get("yoffset")).intValue() : 0;

        Interaction mouseMove = mouse.createPointerMove(Duration.ofMillis(200), origin, x, y);
        return ImmutableMap.<String, Object>builder()
            .put("actions", ImmutableList.of(new Sequence(mouse, 0).addAction(mouseMove).toJson()))
            .build();

      case DriverCommand.SEND_KEYS_TO_ACTIVE_ELEMENT:
      case DriverCommand.SEND_KEYS_TO_ELEMENT:
        // When converted from JSON, this is a list, not an array
        Object rawValue = parameters.get("value");
        Stream<CharSequence> source;
        if (rawValue instanceof Collection) {
          //noinspection unchecked
          source = ((Collection<CharSequence>) rawValue).stream();
        } else {
          source = Stream.of((CharSequence[]) rawValue);
        }

        String text = source
            .flatMap(Stream::of)
            .collect(Collectors.joining());
        return ImmutableMap.<String, Object>builder()
            .putAll(
                parameters.entrySet().stream()
                    .filter(e -> !"text".equals(e.getKey()))
                    .filter(e -> !"value".equals(e.getKey()))
                    .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue)))
            .put("text", text)
            .put("value", stringToUtf8Array(text))
            .build();

      case DriverCommand.SET_ALERT_VALUE:
        return ImmutableMap.<String, Object>builder()
          .put("text", parameters.get("text"))
          .put("value", stringToUtf8Array((String) parameters.get("text")))
          .build();

      case DriverCommand.SET_TIMEOUT:
        String timeoutType = (String) parameters.get("type");
        Number duration = (Number) parameters.get("ms");

        if (timeoutType == null) {
          // Assume a local end that Knows What To Do according to the spec
          return parameters;
        }

        return ImmutableMap.<String, Object>builder()
          .putAll(
            parameters.entrySet().stream()
              .filter(e -> !timeoutType.equals(e.getKey()))
              .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue)))
          .put(timeoutType, duration)
          .build();

      case DriverCommand.SUBMIT_ELEMENT:
        return toScript(
          "var form = arguments[0];\n" +
          "while (form.nodeName != \"FORM\" && form.parentNode) {\n" +
          "  form = form.parentNode;\n" +
          "}\n" +
          "if (!form) { throw Error('Unable to find containing form element'); }\n" +
          "if (!form.ownerDocument) { throw Error('Unable to find owning document'); }\n" +
          "var e = form.ownerDocument.createEvent('Event');\n" +
          "e.initEvent('submit', true, true);\n" +
          "if (form.dispatchEvent(e)) { HTMLFormElement.prototype.submit.call(form) }\n",
          asElement(parameters.get("id")));

      default:
        return parameters;
    }
  }

  private List<String> stringToUtf8Array(String toConvert) {
    List<String> toReturn = new ArrayList<>();
    int offset = 0;
    while (offset < toConvert.length()) {
      int next = toConvert.codePointAt(offset);
      toReturn.add(new StringBuilder().appendCodePoint(next).toString());
      offset += Character.charCount(next);
    }
    return toReturn;
  }

  private Map<String, ?> executeAtom(String atomFileName, Object... args) {
    try {
      String scriptName = "/org/openqa/selenium/remote/" + atomFileName;
      URL url = getClass().getResource(scriptName);

      String rawFunction = Resources.toString(url, StandardCharsets.UTF_8);
      String script = String.format(
        "return (%s).apply(null, arguments);",
        rawFunction);
      return toScript(script, args);
    } catch (IOException | NullPointerException e) {
      throw new WebDriverException(e);
    }
  }

  private Map<String, ?> toScript(String script, Object... args) {
    // Escape the quote marks
    script = script.replaceAll("\"", "\\\"");

    List<Object> convertedArgs = Stream.of(args).map(new WebElementToJsonConverter()).collect(
        Collectors.toList());

    return ImmutableMap.of(
      "script", script,
      "args", convertedArgs);
  }

  private Map<String, String> asElement(Object id) {
    return ImmutableMap.of("element-6066-11e4-a52e-4f735466cecf", (String) id);
  }

  private String cssEscape(String using) {
    using = using.replaceAll("([\\s'\"\\\\#.:;,!?+<>=~*^$|%&@`{}\\-\\/\\[\\]\\(\\)])", "\\\\$1");
    if (using.length() > 0 && Character.isDigit(using.charAt(0))) {
      using = "\\" + Integer.toString(30 + Integer.parseInt(using.substring(0,1))) + " " + using.substring(1);
    }
    return using;
  }
}
