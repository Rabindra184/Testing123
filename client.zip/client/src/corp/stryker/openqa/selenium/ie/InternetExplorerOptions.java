// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

package corp.stryker.openqa.selenium.ie;

import static corp.stryker.openqa.selenium.remote.CapabilityType.BROWSER_NAME;
import static corp.stryker.openqa.selenium.remote.CapabilityType.PAGE_LOAD_STRATEGY;
import static corp.stryker.openqa.selenium.remote.CapabilityType.UNHANDLED_PROMPT_BEHAVIOUR;

import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSortedSet;
import com.google.common.collect.Streams;

import corp.stryker.openqa.selenium.Beta;
import corp.stryker.openqa.selenium.Capabilities;
import corp.stryker.openqa.selenium.MutableCapabilities;
import corp.stryker.openqa.selenium.PageLoadStrategy;
import corp.stryker.openqa.selenium.Proxy;
import corp.stryker.openqa.selenium.UnexpectedAlertBehaviour;
import corp.stryker.openqa.selenium.remote.BrowserType;
import corp.stryker.openqa.selenium.remote.CapabilityType;

import java.time.Duration;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Options for configuring the use of IE. Can be used like so:
 * <pre>InternetExplorerOptions options = new InternetExplorerOptions()
 *   .requireWindowFocus();
 *
 *new InternetExplorerDriver(options);</pre>
 */
@Beta
public class InternetExplorerOptions extends MutableCapabilities {

  final static String IE_OPTIONS = "se:ieOptions";

  private static final String FULL_PAGE_SCREENSHOT = "ie.enableFullPageScreenshot";
  private static final String UPLOAD_DIALOG_TIMEOUT = "ie.fileUploadDialogTimeout";
  private static final String FORCE_WINDOW_SHELL_API = "ie.forceShellWindowsApi";
  private static final String VALIDATE_COOKIE_DOCUMENT_TYPE = "ie.validateCookieDocumentType";

  private final static Set<String> CAPABILITY_NAMES = ImmutableSortedSet.<String>naturalOrder()
      .add(InternetExplorerDriver.BROWSER_ATTACH_TIMEOUT)
      .add(InternetExplorerDriver.ELEMENT_SCROLL_BEHAVIOR)
      .add(InternetExplorerDriver.ENABLE_PERSISTENT_HOVERING)
      .add(FULL_PAGE_SCREENSHOT)
      .add(InternetExplorerDriver.FORCE_CREATE_PROCESS)
      .add(FORCE_WINDOW_SHELL_API)
      .add(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION)
      .add(InternetExplorerDriver.IE_SWITCHES)
      .add(InternetExplorerDriver.IE_USE_PER_PROCESS_PROXY)
      .add(InternetExplorerDriver.IGNORE_ZOOM_SETTING)
      .add(InternetExplorerDriver.INITIAL_BROWSER_URL)
      .add(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS)
      .add(InternetExplorerDriver.REQUIRE_WINDOW_FOCUS)
      .add(UPLOAD_DIALOG_TIMEOUT)
      .add(VALIDATE_COOKIE_DOCUMENT_TYPE)
      .add(InternetExplorerDriver.NATIVE_EVENTS)
      .build();

  private Map<String, Object> ieOptions = new HashMap<>();

  public InternetExplorerOptions() {
    setCapability(BROWSER_NAME, BrowserType.IE);
    setCapability(IE_OPTIONS, ieOptions);
  }

  public InternetExplorerOptions(Capabilities source) {
    this();

    merge(source);
  }

  @Override
  public InternetExplorerOptions merge(Capabilities extraCapabilities) {
    super.merge(extraCapabilities);
    return this;
  }

  public InternetExplorerOptions withAttachTimeout(long duration, TimeUnit unit) {
    return withAttachTimeout(Duration.ofMillis(unit.toMillis(duration)));
  }

  public InternetExplorerOptions withAttachTimeout(Duration duration) {
    return amend(InternetExplorerDriver.BROWSER_ATTACH_TIMEOUT, duration.toMillis());
  }

  public InternetExplorerOptions elementScrollTo(ElementScrollBehavior behavior) {
    return amend(InternetExplorerDriver.ELEMENT_SCROLL_BEHAVIOR, behavior.getValue());
  }

  /**
   * Enable persistently sending {@code WM_MOUSEMOVE} messages to the IE window during a mouse
   * hover.
   */
  public InternetExplorerOptions enablePersistentHovering() {
    return amend(InternetExplorerDriver.ENABLE_PERSISTENT_HOVERING, true);
  }

  /**
   * Force the use of the Windows CreateProcess API when launching Internet Explorer.
   */
  public InternetExplorerOptions useCreateProcessApiToLaunchIe() {
    return amend(InternetExplorerDriver.FORCE_CREATE_PROCESS, true);
  }

  /**
   * Use the Windows ShellWindows API when attaching to Internet Explorer.
   */
  public InternetExplorerOptions useShellWindowsApiToAttachToIe() {
    return amend(FORCE_WINDOW_SHELL_API, true);
  }

  /**
   * Clear the Internet Explorer cache before launching the browser. When set clears the system
   * cache for all instances of Internet Explorer, even those already running when the driven
   * instance is launched.
   */
  public InternetExplorerOptions destructivelyEnsureCleanSession() {
    return amend(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);
  }

  public InternetExplorerOptions addCommandSwitches(String... switches) {
    Object raw = getCapability(InternetExplorerDriver.IE_SWITCHES);
    if (raw == null) {
      raw = new LinkedList<>();
    } else if (raw instanceof String) {
      raw = Arrays.asList(((String) raw).split(" "));
    }

    return amend(
        InternetExplorerDriver.IE_SWITCHES,
        Streams.concat((Stream<?>) List.class.cast(raw).stream(), Stream.of(switches))
            .filter(i -> i instanceof String)
            .map(String.class::cast)
            .collect(ImmutableList.toImmutableList()));
  }

  /**
   *  Use the {@link Proxy} defined in other {@link Capabilities} on a
   *  per-process basis, not updating the system installed proxy setting. This is only valid when
   *  setting a {@link Proxy} where the
   *  {@link Proxy.ProxyType} is one of
   *  <ul>
   *    <li>{@link Proxy.ProxyType#DIRECT}
   *    <li>{@link Proxy.ProxyType#MANUAL}
   *    <li>{@link Proxy.ProxyType#SYSTEM}
   * </ul>
   */
  public InternetExplorerOptions usePerProcessProxy() {
    return amend(InternetExplorerDriver.IE_USE_PER_PROCESS_PROXY, true);
  }

  public InternetExplorerOptions withInitialBrowserUrl(String url) {
    return amend(InternetExplorerDriver.INITIAL_BROWSER_URL, Preconditions.checkNotNull(url));
  }

  public InternetExplorerOptions requireWindowFocus() {
    return amend(InternetExplorerDriver.REQUIRE_WINDOW_FOCUS, true);
  }

  public InternetExplorerOptions waitForUploadDialogUpTo(long duration, TimeUnit unit) {
    return waitForUploadDialogUpTo(Duration.ofMillis(unit.toMillis(duration)));
  }

  public InternetExplorerOptions waitForUploadDialogUpTo(Duration duration) {
    return amend(UPLOAD_DIALOG_TIMEOUT, duration.toMillis());
  }

  public InternetExplorerOptions introduceFlakinessByIgnoringSecurityDomains() {
    return amend(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
  }

  @Deprecated
  public InternetExplorerOptions enableNativeEvents() {
    return amend(InternetExplorerDriver.NATIVE_EVENTS, true);
  }

  public InternetExplorerOptions disableNativeEvents() {
    return  amend(InternetExplorerDriver.NATIVE_EVENTS, false);
  }

  public InternetExplorerOptions ignoreZoomSettings() {
    return amend(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
  }

  public InternetExplorerOptions takeFullPageScreenshot() {
    return amend(FULL_PAGE_SCREENSHOT, true);
  }

  public InternetExplorerOptions setPageLoadStrategy(PageLoadStrategy strategy) {
    return amend(PAGE_LOAD_STRATEGY, strategy);
  }

  public InternetExplorerOptions setUnhandledPromptBehaviour(UnexpectedAlertBehaviour behaviour) {
    return amend(UNHANDLED_PROMPT_BEHAVIOUR, behaviour);
  }

  public InternetExplorerOptions setProxy(Proxy proxy) {
    setCapability(CapabilityType.PROXY, proxy);
    return this;
  }

  private InternetExplorerOptions amend(String optionName, Object value) {
    setCapability(optionName, value);
    return this;
  }

  @Override
  public void setCapability(String key, Object value) {
    super.setCapability(key, value);

    if (InternetExplorerDriver.IE_SWITCHES.equals(key)) {
      if (value instanceof List) {
        value = ((List<?>) value).stream().map(Object::toString).collect(Collectors.joining(" "));
      }
    }

    if (CAPABILITY_NAMES.contains(key)) {
      ieOptions.put(key, value);
    }

    if (IE_OPTIONS.equals(key)) {
      ieOptions.clear();
      Map<?, ?> streamFrom;
      if (value instanceof Map) {
        streamFrom = (Map<?, ?>) value;
      } else if (value instanceof Capabilities) {
        streamFrom = ((Capabilities) value).asMap();
      } else {
        throw new IllegalArgumentException("Value must not be null for " + key);
      }

      streamFrom.entrySet().stream()
          .filter(e -> CAPABILITY_NAMES.contains(e.getKey()))
          .filter(e -> e.getValue() != null)
          .forEach(e -> setCapability((String) e.getKey(), e.getValue()));
    }
  }
}
