package test;

import corp.stryker.openqa.selenium.WebDriver;
import corp.stryker.openqa.selenium.chrome.ChromeDriver;


/**
 * @author Rabindra Biswal
 * @since 16/06/23 9:34 am
 */

public class Test {

  public static void main(String[] args) {
    WebDriver driver= new ChromeDriver();
  }

}
